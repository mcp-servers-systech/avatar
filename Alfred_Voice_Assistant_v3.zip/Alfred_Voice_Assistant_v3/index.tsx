/**
 * Alfred Voice Assistant — Gemini Live (TEXT) -> Azure TTS (audio + visemes)
 * + Snowflake SQL tools (/tools/run_sql, /tools/schema)
 * + DOC_TOOL (Cortex Search) via /tools/doc_search
 * - English/Arabic only, male voices only
 *
 * Requirements:
 *   - npm i @google/genai
 *   - index.html loads Azure Speech SDK: <script src="https://aka.ms/csspeech/jsbrowserpackageraw"></script>
 *   - utils.ts exports createBlob(Float32Array): Blob (16 kHz PCM)
 *   - visual-mascot.ts defines <gdm-live-audio-visuals-mascot> with setViseme(id:number)
 *   - VITE_GEMINI_API_KEY in .env.local
 */

import { GoogleGenAI, Modality, type Session, type LiveServerMessage } from '@google/genai';
import { LitElement, css, html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { createBlob } from './utils.ts';
import './visual-mascot';

declare global { interface Window { SpeechSDK: any; GEMINI_API_KEY?: string } }

const LIVE_MODELS = ['gemini-2.0-flash-live-001', 'gemini-live-2.5-flash-preview'];

/* ---- Allowed male voices ---- */
const VOICES = {
  en: ['en-US-GuyNeural', 'en-GB-RyanNeural'],
  ar: ['ar-SA-HamedNeural', 'ar-EG-ShakirNeural', 'ar-AE-FahedNeural'],
};
const ALL_ALLOWED = new Set([...VOICES.en, ...VOICES.ar]);

/* ---- Tools base URL (same-origin if unset) ---- */
const TOOLS_BASE =
  ((import.meta as any).env?.VITE_TOOLS_URL?.replace(/\/+$/, '')) || ''; // '' => same origin (http://localhost:5173)

/* ---- Tiny WebAudio player for raw 24 kHz PCM ---- */
class PcmaPlayer {
  readonly ctx: AudioContext;
  private playHead = 0;
  private started = false;
  private prebufferSec = 0.12;
  private _basePerfMs = 0;
  constructor(sampleRate = 24000) {
    this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate });
  }
  writePcm16(buf: ArrayBuffer) {
    const i16 = new Int16Array(buf);
    const f32 = new Float32Array(i16.length);
    for (let i = 0; i < i16.length; i++) f32[i] = i16[i] / 0x8000;
    const abuf = this.ctx.createBuffer(1, f32.length, this.ctx.sampleRate);
    abuf.copyToChannel(f32, 0, 0);
    const src = this.ctx.createBufferSource();
    src.buffer = abuf; src.connect(this.ctx.destination);
    if (!this.started) {
      this.playHead = this.ctx.currentTime + this.prebufferSec;
      this._basePerfMs = performance.now() + this.prebufferSec * 1000;
      this.started = true;
    }
    src.start(this.playHead);
    this.playHead += f32.length / this.ctx.sampleRate;
  }
  get basePerfMs() { return this._basePerfMs; }
  close() { try { this.ctx.close(); } catch {} }
}

@customElement('gdm-live-audio')
export class GdmLiveAudio extends LitElement {
  @state() private isRecording = false;
  @state() private status = 'Ready';
  @state() private error = '';

  @state() private language: 'en' | 'ar' | 'auto' = 'auto';

  private ai!: GoogleGenAI;
  private session!: Session;

  private ac = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
  private stream?: MediaStream;
  private src?: MediaStreamAudioSourceNode;
  private proc?: ScriptProcessorNode;

  private vadActive = false; private voiceMs = 0; private silenceMs = 0;
  private readonly START_THRESH = 0.0045;
  private readonly START_MIN_MS = 120;
  private readonly END_SIL_MS = 350;

  @state() private azureKey = '';
  @state() private azureRegion = '';
  @state() private azureVoice = VOICES.en[0];
  private player?: PcmaPlayer;
  private visemeQueue: Array<{ tMs: number, id: number }> = [];

  private pendingText = ''; private tDebounce?: number;

  @state() private showDebug = true; private logs: string[] = []; private turn = 0;

  static styles = css`
    :host { display:block; width:100%; height:100vh; position:relative; background:#fff; }
    gdm-live-audio-visuals-mascot { position:absolute; top:54%; left:50%; transform:translate(-50%,-50%); z-index:5; pointer-events:none; --mouth-top:34%; --mouth-left:50%; --mouth-width:42%; }
    .bar { position:absolute; top:16px; left:16px; right:16px; z-index:20; background:#2f2f2f; color:#fff; border-radius:12px; padding:12px; display:grid; gap:8px; }
    .row { display:grid; grid-template-columns:1fr 1fr; gap:8px; }
    input, select, button { font:14px system-ui,sans-serif; padding:8px; border-radius:8px; border:1px solid #ddd; }
    .controls { position:absolute; bottom:10vh; left:0; right:0; display:flex; gap:10px; justify-content:center; z-index:10; }
    .controls button { width:64px; height:64px; border-radius:16px; cursor:pointer; border:1px solid #ddd; background:#f3f3f3; }
    .status { position:absolute; bottom:4vh; left:0; right:0; text-align:center; color:#333; font:14px system-ui; }
    .debug { position:fixed; right:16px; top:16px; width:min(42vw,560px); height:64vh; z-index:99; background:#0c0c0c; color:#95ff95; border:2px solid #2cf52c; border-radius:12px; padding:10px; overflow:auto; font:12px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; white-space:pre-wrap; box-shadow:0 10px 40px rgba(0,0,0,.4); }
    .label { color:#bbb; font-size:12px; align-self:center; }
  `;

  constructor() { super(); this.initGemini(); }

  private log(msg: string, data?: any) {
    const line = `[${new Date().toLocaleTimeString()}] ${msg}` + (data ? ` ${JSON.stringify(data)}` : '');
    this.logs.unshift(line); if (this.logs.length > 800) this.logs.length = 800;
    console.log('[Alfred]', msg, data ?? ''); this.requestUpdate();
  }

  /* ---- Language helpers ---- */
  private getSystemInstruction() {
    if (this.language === 'en')
      return 'You are Alfred. Reply ONLY in English. If the user speaks another language, respond in English. Be Calm and Polite. Understand the Questions Properly and if the questions are related to Insurance/Banking/Finance, call necessary tools and respond to the Question. If its a eneric Question, Tool calling is not needed.';
    if (this.language === 'ar')
      return 'You are Alfred. Reply ONLY in Arabic (Modern Standard Arabic). If the user speaks another language, respond in Arabic.';
    return 'You are Alfred. If the user speaks Arabic, reply in Arabic (MSA). Otherwise reply in English.';
  }
  private isArabicText(s: string) { return /[\u0600-\u06FF]/.test(s); }
  private defaultVoiceFor(lang: 'en'|'ar') { return lang === 'en' ? VOICES.en[0] : VOICES.ar[0]; }
  private coerceVoiceFor(lang: 'en'|'ar', v: string) {
    if (!ALL_ALLOWED.has(v)) return this.defaultVoiceFor(lang);
    if (lang==='en' && !VOICES.en.includes(v)) return this.defaultVoiceFor('en');
    if (lang==='ar' && !VOICES.ar.includes(v)) return this.defaultVoiceFor('ar');
    return v;
  }
  private pickVoiceForUtterance(text: string) {
    if (this.language==='en') return this.coerceVoiceFor('en', this.azureVoice);
    if (this.language==='ar') return this.coerceVoiceFor('ar', this.azureVoice);
    const lang: 'en'|'ar' = this.isArabicText(text) ? 'ar' : 'en';
    const v = this.coerceVoiceFor(lang, this.azureVoice);
    if (v !== this.azureVoice) this.log('Auto-switched voice for utterance', { chosen: v, detectedLang: lang });
    return v;
  }

  /* ---- Gemini Live (TEXT only, with tools ARRAY) ---- */
  private async initGemini() {
    const key = (import.meta as any).env?.VITE_GEMINI_API_KEY || window.GEMINI_API_KEY;
    if (!key) { this.updateStatus('Add VITE_GEMINI_API_KEY in .env.local or set window.GEMINI_API_KEY.'); return; }

    this.ai = new GoogleGenAI({ apiKey: key });

    const tools = [{
      functionDeclarations: [
        {
          name: "run_sql",
          description: "Run a read-only SELECT on Snowflake and return rows.",
          parameters: {
            type: "OBJECT",
            properties: {
              sql: { type: "STRING", description: "SELECT with ? placeholders for binds" },
              params: { type: "ARRAY", items: { type: "STRING" }, description: "Positional values for ? binds" }
            },
            required: ["sql"]
          }
        },
        {
          name: "get_schema",
          description: "List tables/columns to help compose correct SQL.",
          parameters: { type: "OBJECT", properties: {} }
        },
        {
          name: "DOC_TOOL",
          description: "Search the Cortex Search Service for relevant document chunks and return snippets.",
          parameters: {
            type: "OBJECT",
            properties: {
              query: { type: "STRING", description: "What to search for in the documents" },
              limit: { type: "NUMBER", description: "Max results (default 5)" }
            },
            required: ["query"]
          }
        }
      ]
    }];

    let lastErr: any;
    for (const model of LIVE_MODELS) {
      try {
        this.session = await this.ai.live.connect({
          model,
          config: {
            responseModalities: [Modality.TEXT],
            systemInstruction:
              this.getSystemInstruction() +
              ' For database facts: call get_schema if needed, then call run_sql with a safe SELECT using ? binds. ' +
              'For unstructured documents: call DOC_TOOL with the user’s request as {query}. Use the returned snippets to answer briefly.',
            realtimeInputConfig: { automaticActivityDetection: { disabled: true } },
            tools // <-- array form (fixes "tools is not iterable")
          },
          callbacks: {
            onopen: () => { this.updateStatus(`✅ Connected (${model}) — click Start to speak`); this.log('Gemini connected', { model, language: this.language }); },
            onmessage: (m: LiveServerMessage) => this.onGeminiMessage(m),
            onerror: (e: ErrorEvent) => this.updateError('Gemini error: ' + e.message),
            onclose: (e: CloseEvent) => this.updateStatus(`Connection closed: ${e.reason || '—'}`),
          },
        });
        return;
      } catch (err) { lastErr = err; }
    }
    this.updateError('Failed to connect to Gemini Live: ' + (lastErr?.message || lastErr));
  }

  private async onGeminiMessage(message: LiveServerMessage) {
    const tc: any = (message as any).toolCall;
    if (tc?.functionCalls?.length) {
      for (const fc of tc.functionCalls) await this.handleToolFunctionCall(fc);
      return;
    }

    const sc: any = (message as any).serverContent;
    if (sc) {
      const embedded = sc?.modelTurn?.toolCalls ?? sc?.toolCalls ?? [];
      if (embedded.length) {
        for (const c of embedded) {
          const fc = c.functionCall ?? c.function_call;
          if (fc) await this.handleToolFunctionCall(fc);
        }
        return;
      }
    }

    const parts = sc?.modelTurn?.parts || [];
    for (const p of parts) if (p?.text) this.pendingText += p.text;

    if (sc?.generationComplete || sc?.turnComplete) {
      const text = this.pendingText.trim(); this.pendingText = '';
      if (text) this.azureSpeak(text);
    } else {
      if (this.tDebounce) clearTimeout(this.tDebounce);
      this.tDebounce = window.setTimeout(() => {
        const text = this.pendingText.trim(); this.pendingText = '';
        if (text) this.azureSpeak(text);
      }, 160);
    }
  }

  private async handleToolFunctionCall(fc: any) {
    const name = fc.name; const id = fc.id;
    try {
      if (name === 'run_sql') {
        const body = { sql: fc.args?.sql, params: fc.args?.params ?? [] };
        this.log('SNOWFLAKE RUN_SQL →', { sql: body.sql, params: body.params?.length || 0 });
        const r = await fetch(`${TOOLS_BASE}/tools/run_sql`, {
          method: 'POST', headers: { 'Content-Type':'application/json' }, body: JSON.stringify(body)
        }).then(r => r.json());
        this.log('SNOWFLAKE RESULT ←', { rowCount: r?.rowCount, columns: r?.columns?.length });
        await (this.session as any).sendToolResponse?.({ functionResponses: [{ id, name, response: { result: r } }] });
        return;
      }

      if (name === 'get_schema') {
        this.log('SNOWFLAKE GET_SCHEMA →');
        const r = await fetch(`${TOOLS_BASE}/tools/schema`).then(r => r.json());
        this.log('SNOWFLAKE SCHEMA ←', { rows: r?.rowCount, columns: r?.columns?.length });
        await (this.session as any).sendToolResponse?.({ functionResponses: [{ id, name, response: { result: r } }] });
        return;
      }

      if (name === 'DOC_TOOL') {
        const body = { query: fc.args?.query, limit: fc.args?.limit ?? 5 };
        this.log('DOC_TOOL → Cortex Search', body);
        const r = await fetch(`${TOOLS_BASE}/tools/doc_search`, {
          method: 'POST', headers: { 'Content-Type':'application/json' }, body: JSON.stringify(body)
        }).then(r => r.json());
        this.log('DOC_TOOL ← results', { total: r?.results?.length ?? 0 });
        await (this.session as any).sendToolResponse?.({ functionResponses: [{ id, name, response: { result: r } }] });
        return;
      }

      this.log('UNKNOWN TOOL', { name });
      await (this.session as any).sendToolResponse?.({ functionResponses: [{ id, name, response: { error: `Unknown tool ${name}` } }] });
    } catch (e: any) {
      this.log('TOOL ERROR', { tool: name, error: e?.message || String(e) });
      await (this.session as any).sendToolResponse?.({ functionResponses: [{ id, name, response: { error: e?.message || String(e) } }] });
    }
  }

  /* ---- Azure TTS + visemes ---- */
  private azureSpeak(text: string) {
    const SDK = window.SpeechSDK;
    if (!SDK) { this.updateError('Azure Speech SDK not loaded'); return; }
    if (!this.azureKey || !this.azureRegion) { this.updateStatus('Enter Azure key & region'); return; }

    const chosenVoice = this.pickVoiceForUtterance(text);
    if (this.azureVoice !== chosenVoice) { this.log('Enforcing male voice', { from: this.azureVoice, to: chosenVoice }); this.azureVoice = chosenVoice; }

    const speechConfig = SDK.SpeechConfig.fromSubscription(this.azureKey, this.azureRegion);
    speechConfig.speechSynthesisVoiceName = this.azureVoice;
    if ((SDK as any).SpeechSynthesisOutputFormat?.Raw24Khz16BitMonoPcm !== undefined) {
      (speechConfig as any).speechSynthesisOutputFormat = (SDK as any).SpeechSynthesisOutputFormat.Raw24Khz16BitMonoPcm;
    }

    this.player?.close(); this.player = new PcmaPlayer(24000); this.visemeQueue.length = 0;

    const push = SDK.PushAudioOutputStream.create({
      write: (dataBuffer: ArrayBuffer) => { this.player!.writePcm16(dataBuffer); if (this.player!.basePerfMs && this.visemeQueue.length) this.flushQueuedVisemes(); return dataBuffer.byteLength; },
      close: () => {}
    });
    const audioConfig = SDK.AudioConfig.fromStreamOutput(push);
    const synth = new SDK.SpeechSynthesizer(speechConfig, audioConfig);

    synth.visemeReceived = (_: any, e: any) => {
      const tMs = e.audioOffset / 10000; const base = this.player!.basePerfMs;
      if (!base) { this.visemeQueue.push({ tMs, id: e.visemeId }); return; }
      const eta = Math.max(0, tMs - (performance.now() - base));
      window.setTimeout(() => this.mascot?.setViseme?.(e.visemeId), eta);
    };
    synth.synthesisCompleted = () => { window.setTimeout(() => this.mascot?.setViseme?.(0), 120); try { synth.close(); } catch {} };

    this.log('Azure speak', { voice: this.azureVoice, langMode: this.language, text: text.slice(0, 160) });
    synth.speakTextAsync(text, () => {}, (err: any) => { console.error(err); this.updateError('Azure TTS error: ' + err); try { synth.close(); } catch {} });
  }

  private flushQueuedVisemes() {
    const base = this.player!.basePerfMs; if (!base) return;
    this.log('Flushing queued visemes', { count: this.visemeQueue.length });
    for (const v of this.visemeQueue) {
      const eta = Math.max(0, v.tMs - (performance.now() - base));
      window.setTimeout(() => this.mascot?.setViseme?.(v.id), eta);
    }
    this.visemeQueue.length = 0;
  }

  private get mascot() { return this.renderRoot?.querySelector('gdm-live-audio-visuals-mascot') as any; }

  /* ---- Mic -> Gemini (VAD-first) ---- */
  private async startRecording() {
    if (this.isRecording) return;
    try {
      await this.ac.resume();
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, noiseSuppression: true, echoCancellation: true, autoGainControl: false }, video: false });
      this.src = this.ac.createMediaStreamSource(this.stream);
      const proc = this.ac.createScriptProcessor(256, 1, 1); this.proc = proc;

      this.vadActive = false; this.voiceMs = 0; this.silenceMs = 0; this.turn++; this.log(`TURN #${this.turn} — listening…`);

      proc.onaudioprocess = (ev) => {
        if (!this.isRecording) return;
        const pcm = ev.inputBuffer.getChannelData(0);
        let s = 0; for (let i = 0; i < pcm.length; i++) s += pcm[i] * pcm[i];
        const rms = Math.sqrt(s / pcm.length); const voiced = rms > this.START_THRESH;

        if (!this.vadActive) {
          if (voiced) this.voiceMs += (pcm.length / 16000) * 1000; else this.voiceMs = 0;
          if (this.voiceMs >= this.START_MIN_MS) {
            this.session?.sendRealtimeInput?.({ activityStart: {} }); this.vadActive = true; this.log(`TURN #${this.turn} — activityStart sent`);
            this.session?.sendRealtimeInput?.({ media: createBlob(pcm) }); return;
          }
          return;
        }

        this.session?.sendRealtimeInput?.({ media: createBlob(pcm) });
        if (voiced) { this.silenceMs = 0; }
        else {
          this.silenceMs += (pcm.length / 16000) * 1000;
          if (this.silenceMs > this.END_SIL_MS) {
            this.session?.sendRealtimeInput?.({ activityEnd: {} });
            this.vadActive = false; this.voiceMs = 0; this.silenceMs = 0; this.log(`TURN #${this.turn} — activityEnd sent`);
          }
        }
      };

      this.src.connect(proc); proc.connect(this.ac.destination);
      this.isRecording = true; this.updateStatus('🎤 Recording — speak now');
    } catch (e: any) { console.error(e); this.updateError('Mic error: ' + (e?.message || e)); this.stopRecording(); }
  }

  private stopRecording() {
    if (!this.isRecording) return;
    this.isRecording = false;
    if (this.vadActive) { this.session?.sendRealtimeInput?.({ activityEnd: {} }); this.vadActive = false; }
    this.proc?.disconnect(); this.proc = undefined; this.src?.disconnect(); this.src = undefined;
    this.stream?.getTracks().forEach(t => t.stop()); this.stream = undefined;
    this.updateStatus('⏸️ Stopped');
  }

  private updateStatus(s: string) { this.status = s; this.error = ''; this.log('STATUS ' + s); }
  private updateError(s: string) { this.error = s; this.log('ERROR ' + s); }
  private resetSession() { try { this.session?.close?.(); } catch {} this.initGemini(); }

  private onLanguageChange(lang: 'en'|'ar'|'auto') {
    this.language = lang;
    if (lang === 'en') this.azureVoice = this.coerceVoiceFor('en', this.azureVoice);
    if (lang === 'ar') this.azureVoice = this.coerceVoiceFor('ar', this.azureVoice);
    this.log('Language mode changed', { language: lang, voice: this.azureVoice });
    this.resetSession();
  }

  render() {
    const voiceOptions = this.language === 'ar' ? VOICES.ar : this.language === 'en' ? VOICES.en : [...VOICES.en, ...VOICES.ar];
    return html`
      <gdm-live-audio-visuals-mascot></gdm-live-audio-visuals-mascot>

      <div class="bar">
        <div class="row">
          <div class="label">Reply language</div>
          <select .value=${this.language} @change=${(e:any)=>this.onLanguageChange(e.target.value)}>
            <option value="auto">Auto — English unless Arabic detected</option>
            <option value="en">English (Male)</option>
            <option value="ar">Arabic (Male)</option>
          </select>
        </div>

        <div class="row">
          <input placeholder="Azure Speech key" .value=${this.azureKey} @input=${(e:any)=>this.azureKey=e.target.value} />
          <input placeholder="Region (e.g. eastus)" .value=${this.azureRegion} @input=${(e:any)=>this.azureRegion=e.target.value} />
        </div>

        <div class="row">
          <div class="label">Male voice</div>
          <select .value=${this.azureVoice} @change=${(e:any)=>{ const v=e.target.value; if (ALL_ALLOWED.has(v)) this.azureVoice=v; }}>
            ${voiceOptions.map(v => html`<option value=${v}>${v}</option>`)}
          </select>
        </div>
      </div>

      <div class="controls">
        <button title="Reset" @click=${this.resetSession} ?disabled=${this.isRecording}>⟳</button>
        <button title="Start" @click=${this.startRecording} ?disabled=${this.isRecording}>●</button>
        <button title="Stop"  @click=${this.stopRecording} ?disabled=${!this.isRecording}>■</button>
      </div>

      <div class="status">${this.error || this.status}</div>
      ${this.showDebug ? html`<div class="debug">${this.logs.join('\n')}</div>` : null}
    `;
  }
}

declare global { interface HTMLElementTagNameMap { 'gdm-live-audio': GdmLiveAudio; } }
