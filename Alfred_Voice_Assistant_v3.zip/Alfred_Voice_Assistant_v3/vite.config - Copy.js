// vite.config.js
import { defineConfig, loadEnv } from 'vite';

export default ({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const cfg = {
    account: env.SNOWFLAKE_ACCOUNT,
    warehouse: env.SNOWFLAKE_WAREHOUSE,
    database: env.SNOWFLAKE_DATABASE,
    schema: env.SNOWFLAKE_SCHEMA,
    role: env.SNOWFLAKE_ROLE,
    bearer: env.SNOWFLAKE_BEARER, // PAT or OAuth token (Bearer)
  };

  function assertEnv() {
    for (const [k, v] of Object.entries(cfg)) {
      if (!v) throw new Error(`[vite snowflake] Missing ${k} in .env.local`);
    }
  }

  const SELECT_ONLY = /^\s*select\b/i;

  async function readJson(req) {
    const chunks = [];
    for await (const c of req) chunks.push(c);
    const raw = Buffer.concat(chunks).toString('utf8') || '{}';
    return JSON.parse(raw);
  }

  function toRows(resp) {
    const cols = (resp.resultSetMetaData?.rowType ?? []).map(c => c.name);
    const rows = (resp.data ?? []).map(r => Object.fromEntries(r.map((v, i) => [cols[i], v])));
    return { columns: cols, rows, rowCount: rows.length };
  }

  async function postStatement(body) {
    const base = `https://${cfg.account}.snowflakecomputing.com`;
    const r = await fetch(`${base}/api/v2/statements`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${cfg.bearer}`,
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    // 202 means “still running”: poll statementStatusUrl until 200. :contentReference[oaicite:3]{index=3}
    if (r.status === 202) {
      const j = await r.json();
      const statusUrl = `${base}${j.statementStatusUrl}`;
      while (true) {
        const sr = await fetch(statusUrl, {
          headers: { 'Authorization': `Bearer ${cfg.bearer}`, 'Accept': 'application/json' }
        });
        if (sr.status === 200) return await sr.json();
        if (sr.status !== 202 && sr.status !== 429) {
          throw new Error(`${sr.status} ${await sr.text()}`);
        }
        await new Promise(res => setTimeout(res, 300));
      }
    }

    if (r.status !== 200) throw new Error(`${r.status} ${await r.text()}`);
    return await r.json();
  }

  return defineConfig({
    plugins: [{
      name: 'snowflake-tools',
      configureServer(server) {
        assertEnv();

        // POST /tools/run_sql  { sql, params?: [] }
        server.middlewares.use('/tools/run_sql', async (req, res) => {
          if (req.method !== 'POST') return res.end('Only POST');
          try {
            const { sql, params = [] } = await readJson(req);
            if (!sql) { res.statusCode = 400; return res.end(JSON.stringify({ error: 'sql required' })); }
            if (!SELECT_ONLY.test(sql)) { res.statusCode = 400; return res.end(JSON.stringify({ error: 'Only SELECT allowed' })); }

            // Map ? binds → bindings object (1-based)  :contentReference[oaicite:4]{index=4}
            const bindings = {};
            params.forEach((val, i) => {
              const idx = String(i + 1);
              const isNum = typeof val === 'number';
              bindings[idx] = { type: isNum ? 'FIXED' : 'TEXT', value: String(val) };
            });

            const body = {
              statement: sql,
              warehouse: cfg.warehouse,
              database: cfg.database,
              schema: cfg.schema,
              role: cfg.role,
              timeout: 30,
              resultSetMetaData: { format: 'jsonv2' }, // JSONV2 rows
              bindings, // ? binds  :contentReference[oaicite:5]{index=5}
            };

            const resp = await postStatement(body);
            const data = toRows(resp);
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify(data));
          } catch (e) {
            res.statusCode = 500;
            res.end(JSON.stringify({ error: String(e.message || e) }));
          }
        });

        // GET /tools/schema
        server.middlewares.use('/tools/schema', async (req, res, next) => {
          if (req.method !== 'GET') return next();
          try {
            const sql = `
              SELECT TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME, DATA_TYPE
              FROM INFORMATION_SCHEMA.COLUMNS
              WHERE TABLE_SCHEMA NOT IN ('INFORMATION_SCHEMA')
              ORDER BY TABLE_SCHEMA, TABLE_NAME, ORDINAL_POSITION
            `;
            const resp = await postStatement({
              statement: sql,
              warehouse: cfg.warehouse,
              database: cfg.database,
              schema: cfg.schema,
              role: cfg.role,
              timeout: 30,
              resultSetMetaData: { format: 'jsonv2' },
            });
            const data = toRows(resp);
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify(data));
          } catch (e) {
            res.statusCode = 500;
            res.end(JSON.stringify({ error: String(e.message || e) }));
          }
        });
      }
    }]
  });
};
