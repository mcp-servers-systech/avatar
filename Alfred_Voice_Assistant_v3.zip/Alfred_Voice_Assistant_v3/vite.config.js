// vite.config.js
import { defineConfig, loadEnv } from 'vite';

export default ({ mode }) => {
  // Load ALL env keys (no VITE_ prefix) from .env.local
  const env = loadEnv(mode, process.cwd(), '');

  // --- SQL API config ---
  const cfg = {
    // For SQL API you may set either:
    //  - SNOWFLAKE_ACCOUNT (like "xy12345.us-east-1.aws") and we'll build the URL, OR
    //  - SNOWFLAKE_ACCOUNT_URL (full https://...snowflakecomputing.com)
    account: env.SNOWFLAKE_ACCOUNT || '',
    accountUrl: env.SNOWFLAKE_ACCOUNT_URL || '',
    warehouse: env.SNOWFLAKE_WAREHOUSE || '',
    database: env.SNOWFLAKE_DATABASE || env.SNOWFLAKE_DB || '',
    schema: env.SNOWFLAKE_SCHEMA || '',
    role: env.SNOWFLAKE_ROLE || '',
    bearer: env.SNOWFLAKE_BEARER || '', // PAT / OAuth bearer token
  };

  // --- Cortex Search config (can reuse DB/SCHEMA above) ---
  const docCfg = {
    accountUrl: env.SNOWFLAKE_ACCOUNT_URL || '', // Cortex REST requires full account URL
    database: env.SNOWFLAKE_DB || env.SNOWFLAKE_DATABASE || '',
    schema: env.SNOWFLAKE_DOC_SCHEMA || env.SNOWFLAKE_SCHEMA || '',
    service: env.SNOWFLAKE_DOC_SERVICE || '', // e.g. INSURANCE_SEARCH
    bearer: env.SNOWFLAKE_BEARER || '',
  };

  function assertSqlEnv() {
    const okAccount = Boolean(cfg.account || cfg.accountUrl);
    const required = [
      ['SNOWFLAKE_ACCOUNT or SNOWFLAKE_ACCOUNT_URL', okAccount],
      ['SNOWFLAKE_WAREHOUSE', !!cfg.warehouse],
      ['SNOWFLAKE_DATABASE (or SNOWFLAKE_DB)', !!cfg.database],
      ['SNOWFLAKE_SCHEMA', !!cfg.schema],
      ['SNOWFLAKE_ROLE', !!cfg.role],
      ['SNOWFLAKE_BEARER', !!cfg.bearer],
    ];
    const missing = required.filter(([, ok]) => !ok).map(([k]) => k);
    if (missing.length) throw new Error(`[vite snowflake] Missing env: ${missing.join(', ')}`);
  }

  function assertDocEnv() {
    const required = [
      ['SNOWFLAKE_ACCOUNT_URL', !!docCfg.accountUrl],
      ['SNOWFLAKE_DB (or SNOWFLAKE_DATABASE)', !!docCfg.database],
      ['SNOWFLAKE_DOC_SCHEMA (or SNOWFLAKE_SCHEMA)', !!docCfg.schema],
      ['SNOWFLAKE_DOC_SERVICE', !!docCfg.service],
      ['SNOWFLAKE_BEARER', !!docCfg.bearer],
    ];
    const missing = required.filter(([, ok]) => !ok).map(([k]) => k);
    if (missing.length) throw new Error(`[vite cortex] Missing env: ${missing.join(', ')}`);
  }

  // Build account base URL
  function sqlBaseUrl() {
    if (cfg.accountUrl) return cfg.accountUrl.replace(/\/+$/, '');
    if (cfg.account) return `https://${cfg.account}.snowflakecomputing.com`;
    throw new Error('No account / accountUrl configured');
  }

  // Helpers
  async function readJson(req) {
    const chunks = [];
    for await (const c of req) chunks.push(c);
    const raw = Buffer.concat(chunks).toString('utf8') || '{}';
    return JSON.parse(raw);
  }

  function toRows(resp) {
    const cols = (resp.resultSetMetaData?.rowType ?? []).map(c => c.name);
    const rows = (resp.data ?? []).map(r => Object.fromEntries(r.map((v, i) => [cols[i], v])));
    return { columns: cols, rows, rowCount: rows.length };
  }

  // POST /api/v2/statements with 202 polling until ready
  async function postStatement(body) {
    const base = sqlBaseUrl();
    const r = await fetch(`${base}/api/v2/statements`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${cfg.bearer}`,
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    if (r.status === 202) {
      const j = await r.json();
      const statusUrl = `${base}${j.statementStatusUrl}`;
      // Poll until 200
      while (true) {
        const sr = await fetch(statusUrl, {
          headers: { 'Authorization': `Bearer ${cfg.bearer}`, 'Accept': 'application/json' }
        });
        if (sr.status === 200) return await sr.json();
        if (sr.status !== 202 && sr.status !== 429) {
          throw new Error(`${sr.status} ${await sr.text()}`);
        }
        await new Promise(res => setTimeout(res, 300));
      }
    }

    if (r.status !== 200) throw new Error(`${r.status} ${await r.text()}`);
    return await r.json();
  }

  const SELECT_ONLY = /^\s*select\b/i;

  return defineConfig({
    plugins: [{
      name: 'snowflake-tools',
      configureServer(server) {
        // Validate env once dev server starts
        assertSqlEnv();
        assertDocEnv();

        // ---------- SQL: run SELECT with binds ----------
        // POST /tools/run_sql  { sql, params?: [] }
        server.middlewares.use('/tools/run_sql', async (req, res) => {
          if (req.method !== 'POST') return res.end('Only POST');
          try {
            const { sql, params = [] } = await readJson(req);
            if (!sql) { res.statusCode = 400; return res.end(JSON.stringify({ error: 'sql required' })); }
            if (!SELECT_ONLY.test(sql)) { res.statusCode = 400; return res.end(JSON.stringify({ error: 'Only SELECT allowed' })); }

            // Map positional ? binds → bindings object (1-based)
            const bindings = {};
            params.forEach((val, i) => {
              const idx = String(i + 1);
              const isNum = typeof val === 'number';
              bindings[idx] = { type: isNum ? 'FIXED' : 'TEXT', value: String(val) };
            });

            const body = {
              statement: sql,
              warehouse: cfg.warehouse,
              database: cfg.database,
              schema: cfg.schema,
              role: cfg.role,
              timeout: 30,
              resultSetMetaData: { format: 'jsonv2' },
              bindings,
            };

            const resp = await postStatement(body);
            const data = toRows(resp);
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify(data));
          } catch (e) {
            res.statusCode = 500;
            res.end(JSON.stringify({ error: String(e.message || e) }));
          }
        });

        // ---------- SQL: read INFORMATION_SCHEMA for quick schema ----------
        // GET /tools/schema
        server.middlewares.use('/tools/schema', async (req, res, next) => {
          if (req.method !== 'GET') return next();
          try {
            const sql = `
              SELECT TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME, DATA_TYPE
              FROM INFORMATION_SCHEMA.COLUMNS
              WHERE TABLE_SCHEMA NOT IN ('INFORMATION_SCHEMA')
              ORDER BY TABLE_SCHEMA, TABLE_NAME, ORDINAL_POSITION
            `;
            const resp = await postStatement({
              statement: sql,
              warehouse: cfg.warehouse,
              database: cfg.database,
              schema: cfg.schema,
              role: cfg.role,
              timeout: 30,
              resultSetMetaData: { format: 'jsonv2' },
            });
            const data = toRows(resp);
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify(data));
          } catch (e) {
            res.statusCode = 500;
            res.end(JSON.stringify({ error: String(e.message || e) }));
          }
        });

        // ---------- Cortex Search Service: query ----------
        // POST /tools/doc_search  { query, columns?:[], filter?:{}, limit?:number }
        server.middlewares.use('/tools/doc_search', async (req, res) => {
          if (req.method !== 'POST') return res.end('Only POST');
          try {
            const { query, columns, filter, limit } = await readJson(req);
            if (!query) { res.statusCode = 400; return res.end(JSON.stringify({ error: 'query required' })); }

            const url = `${docCfg.accountUrl.replace(/\/+$/, '')}/api/v2/databases/${docCfg.database}/schemas/${docCfg.schema}/cortex-search-services/${docCfg.service}:query`;

            const payload = {
              query,
              ...(Array.isArray(columns) ? { columns } : {}),
              ...(filter ? { filter } : {}),
              limit: Number.isFinite(limit) ? limit : 5
            };

            const r = await fetch(url, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Authorization': `Bearer ${docCfg.bearer}`
              },
              body: JSON.stringify(payload)
            });

            const text = await r.text();
            // Forward status / body
            res.statusCode = r.status;
            res.setHeader('Content-Type', 'application/json');
            res.end(text);
          } catch (e) {
            res.statusCode = 500;
            res.end(JSON.stringify({ error: String(e.message || e) }));
          }
        });
      }
    }]
  });
};
