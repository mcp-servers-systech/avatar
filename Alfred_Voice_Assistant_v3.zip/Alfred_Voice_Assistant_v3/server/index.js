require('dotenv').config();
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

const cfg = {
  account: process.env.SNOWFLAKE_ACCOUNT,
  warehouse: process.env.SNOWFLAKE_WAREHOUSE,
  database: process.env.SNOWFLAKE_DATABASE,
  schema: process.env.SNOWFLAKE_SCHEMA,
  role: process.env.SNOWFLAKE_ROLE,
  bearer: process.env.SNOWFLAKE_BEARER, // OAuth / PAT / key-pair JWT
};

function ensureEnv() {
  for (const [k,v] of Object.entries(cfg)) if (!v) throw new Error(`Missing ${k} in server/.env`);
}
ensureEnv();

// SELECT-only gate
const SELECT_ONLY = /^\s*select\b/i;

// Map array params -> SQL API "bindings" object: { "1": {type, value}, ... }
function toBindings(params = []) {
  const bindings = {};
  params.forEach((val, i) => {
    const idx = String(i + 1);
    const isNum = typeof val === 'number';
    bindings[idx] = { type: isNum ? 'FIXED' : 'TEXT', value: String(val) };
  });
  return bindings;
}

function toRows(resp) {
  const cols = (resp.resultSetMetaData?.rowType ?? []).map(c => c.name);
  const rows = (resp.data ?? []).map(r => Object.fromEntries(r.map((v, i) => [cols[i], v])));
  return { columns: cols, rows, rowCount: rows.length };
}

async function postStatement(body) {
  const url = `https://${cfg.account}.snowflakecomputing.com/api/v2/statements`;
  const r = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${cfg.bearer}`,
      'Accept': 'application/json',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  // 202 means “still running” -> poll statementStatusUrl until 200
  if (r.status === 202) {
    const j = await r.json();
    const statusUrl = `https://${cfg.account}.snowflakecomputing.com${j.statementStatusUrl}`;
    // Basic poll loop
    while (true) {
      const sr = await fetch(statusUrl, {
        headers: { 'Authorization': `Bearer ${cfg.bearer}`, 'Accept': 'application/json' }
      });
      if (sr.status === 200) return await sr.json();
      if (sr.status !== 202 && sr.status !== 429) {
        throw new Error(`${sr.status} ${await sr.text()}`);
      }
      await new Promise(r => setTimeout(r, 400));
    }
  }
  if (r.status !== 200) throw new Error(`${r.status} ${await r.text()}`);
  return await r.json();
}

// Tool endpoint: read-only SELECT
app.post('/tools/run_sql', async (req, res) => {
  try {
    const { sql, params = [] } = req.body || {};
    if (!sql) return res.status(400).json({ error: 'sql required' });
    if (!SELECT_ONLY.test(sql)) return res.status(400).json({ error: 'Only SELECT statements allowed' });

    const resp = await postStatement({
      statement: sql,
      warehouse: cfg.warehouse,
      database: cfg.database,
      schema: cfg.schema,
      role: cfg.role,
      timeout: 30,
      // With newer endpoints the format may be ignored, but jsonv2 is fine to request.
      resultSetMetaData: { format: 'jsonv2' },
      // Bindings for “?” placeholders:
      bindings: toBindings(params),
    });
    res.json(toRows(resp));
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: String(e.message || e) });
  }
});

// Tool endpoint: schema listing for the model to compose SQL
app.get('/tools/schema', async (_req, res) => {
  try {
    const sql = `
      SELECT TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME, DATA_TYPE
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_SCHEMA NOT IN ('INFORMATION_SCHEMA')
      ORDER BY TABLE_SCHEMA, TABLE_NAME, ORDINAL_POSITION
    `;
    const resp = await postStatement({
      statement: sql,
      warehouse: cfg.warehouse,
      database: cfg.database,
      schema: cfg.schema,
      role: cfg.role,
      timeout: 30,
      resultSetMetaData: { format: 'jsonv2' },
    });
    res.json(toRows(resp));
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: String(e.message || e) });
  }
});

const port = process.env.PORT || 8787;
app.listen(port, () => console.log(`Snowflake tools server listening on :${port}`));
